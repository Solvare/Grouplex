<?php
/**
 * Database configuration
 */

$dsn = 'mysql:dbname=grouplex;host=localhost';
$user = 'root';
$pass = 'pass123';

?>
